
close all
P = rand(10,2);
plot(P(:,1),P(:,2),'r+')