close all
clear all

P = rand(25,2);
Random_point_repel;


% P= [P; incenter(DT)];
P = incenter(DT);

Random_point_repel;


P = incenter(DT);
Random_point_repel;

P = incenter(DT);
Random_point_repel;

P = incenter(DT);
Random_point_repel;

P = incenter(DT);
Random_point_repel;

